package com.curdexample.springbootcurdexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCurdExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
