package com.curdexample.springbootcurdexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCurdExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCurdExampleApplication.class, args);
	}

}
